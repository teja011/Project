package com.cg.srma.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.srma.entity.CandidatePersonal;
import com.cg.srma.entity.JobRequirements;
import com.cg.srma.service.RecruitmentService;

@Controller
public class HomeController {
	
	@Autowired
RecruitmentService rcs;
	
	@RequestMapping("home")
	public String goHome(Model model) {
		model.addAttribute("cp",new CandidatePersonal());
		return "Register";
	}
	
	@RequestMapping("jobReq")
	public String gojobHome(Model model) {
		model.addAttribute("jr",new JobRequirements());
		return "JobRegister";
	}
	
	
	
	@RequestMapping("register")
	public String register(@ModelAttribute("cp")  @Valid CandidatePersonal cp, BindingResult res, Model model)
	{
		if(res.hasErrors()){
			
			model.addAttribute("cp", cp);
			return "Register";
			
		}
		else{
			
			long canId=rcs.register(cp);
			model.addAttribute("canId",canId);
			return "Success";
		}
	}
	
	
	@RequestMapping("jobregister")
	public String JOBregister(@ModelAttribute("jr")  @Valid JobRequirements jr, BindingResult res, Model model)
	{
		if(res.hasErrors()){
			
			model.addAttribute("jr", jr);
			return "JobRegister";
			
		}
		else{
			
			long jobId=rcs.jobregister(jr);
			model.addAttribute("jobId",jobId);
			return "jSuccess";
		}
	}
	
	@RequestMapping("searjob")
	public String searchT(Model model)
	{
	  
		model.addAttribute("jr", new JobRequirements());
	return "searchjob";
	}
	
	@RequestMapping("sjob")
	public String strainee(Model model,@ModelAttribute("jr")  @Valid JobRequirements jr ){
		
		List<JobRequirements> jlist= rcs.getjob(jr.getQualification_required(),jr.getPosition_required(),jr.getJob_location(),jr.getExperience_required());
		
		model.addAttribute("jlist", jlist);
		model.addAttribute("successMsg", "Student Added ");
		return "Ssuccess";
		
		
	}

	
	
	

	
}

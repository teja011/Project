package com.cg.srma.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="job_requirements")
public class JobRequirements {

	@Id
	@Column(name="job_id")
	@SequenceGenerator(name="jId_seq",sequenceName="jobre_seq_id",allocationSize=1)
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="jId_seq")
	long job_id;
	String company_id;
	String position_required;
	Long number_required;
	String experience_required;
	String qualification_required;
	String job_location;
	String job_description;
	
	
	public JobRequirements() {
		// TODO Auto-generated constructor stub
	}

	public long getJob_id() {
		return job_id;
	}

    public void setJob_id(long job_id) {
		this.job_id = job_id;
	}
    
    public String getCompany_id() {
		return company_id;
	}


	public void setCompany_id(String company_id) {
		this.company_id = company_id;
	}

    public String getPosition_required() {
		return position_required;
	}


	public void setPosition_required(String position_required) {
		this.position_required = position_required;
	}


	public Long getNumber_required() {
		return number_required;
	}


	public void setNumber_required(Long number_required) {
		this.number_required = number_required;
	}


	

	public String getExperience_required() {
		return experience_required;
	}

	public void setExperience_required(String experience_required) {
		this.experience_required = experience_required;
	}

	public String getQualification_required() {
		return qualification_required;
	}


	public void setQualification_required(String qualification_required) {
		this.qualification_required = qualification_required;
	}


	public String getJob_location() {
		return job_location;
	}


	public void setJob_location(String job_location) {
		this.job_location = job_location;
	}


	public String getJob_description() {
		return job_description;
	}


	public void setJob_description(String job_description) {
		this.job_description = job_description;
	}
	
	
	
}

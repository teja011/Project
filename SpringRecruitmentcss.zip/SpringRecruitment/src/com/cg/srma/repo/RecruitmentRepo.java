package com.cg.srma.repo;


import java.util.List;

import com.cg.srma.entity.CandidatePersonal;
import com.cg.srma.entity.CompanyMaster;
import com.cg.srma.entity.JobRequirements;

public interface RecruitmentRepo {
	
	long register(CandidatePersonal cp);
	long jobregister(JobRequirements jr);
	long comregister(CompanyMaster cm);
	/*public JobRequirements findJob(String qualification_required );*/
	public List<JobRequirements> getjob(String qualification_required, String position_required, String job_location, String experience_required);


}
